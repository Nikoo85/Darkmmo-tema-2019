<?php if(!defined("WM_HTML_KONTROL")){ die("Buraya giriş izniniz yoktur."); exit;} ?>
<br>

<div class="row">
<div class="col-md-12">
<table class="table">
<tbody id="ranking-items">
	<?php 
	$i = $limit;
	foreach($query as $row){
	$i++;
	?>
<tr class="ranking-item">
<td>
<div class="race-and-rank top-buffer">
<a href="http://fusion-network.eu/de/spieler-profil/866261">
<span class="label label-default over-image center-block"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Sıra <?=$i;?> </font></font></span>
<span class="badge badge-default ranking-over-image-level"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><?=$row["level"];?></font></font></span>
<img src="<?=$ayar->WMimg.'karekterler/'.$row["job"];?>.jpg" title="Savaşçı (m)" class="img-circle" width="60">
</a>
</div>
</td>
<td>
<h4>
<strong><a href="http://fusion-network.eu/de/spieler-profil/866261"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><?=$row["name"];?></font></font></a>
</strong>
</h4>
<div class="row ">
<div class="col-md-12">
<strong><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><?=$row["lonca"];?></font></font></strong>
</div>
</div>
</td>
<td>
<div class="col-md-12 top-buffer">
<strong><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Aktiflik durumu</font></font></strong><br><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><?=$vt->online_kontrol($row["name"]);?></font></font></div>
</td>
 <td>
<div class="row top-buffer">
<div class="col-md-12"><img src="<?=$ayar->WMimg.'bayrak/'.$row["empire"];?>.png" class="ranking-empire">
</div>
</div>
</td>
</tr>
	<?php 
	}
	?>
	
</tbody>
</table>
</div>
</div>




