
<div class="overview-block">
<div class="content-title">
<h1 class="title"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">genel bakış</font></font></h1>
</div>
<div class="tab-n news active" id="news-1">
<div class="row">
<div class="col">
<h2 class="title"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">hesap</font></font></h2>
<table width="100%">
<tbody><tr>
<td><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">hesap</font></font></td>
<td><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><?=$_SESSION[$vt->a("isim")."username"];?>  &nbsp; 
		<?php if($vt->a("kullanici_degis") != 3){?><a href="kullanici/kullanici-adi-degistir">(Değiştir)</a> <?php } ?></font></font></td>
</tr>
<tr>
<td><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">E-posta:</font></font></td>
<td><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><?=$vt->uye("email");?> &nbsp; 
		<?php if($vt->a("mail_degistir") == 1){?><a href="kullanici/mail-degistir">(Değiştir)</a> <?php } ?></font></font></td>
</tr>
<tr>
<td><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Krallık:</font></font></td>
<td><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><?=$tema->_bayrak($vt->uye("id"));?></font></font></td>
</tr>
<tr>
<td><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Karekter sayısı:</font></font></td>
<td><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><?=$tema->kac_karakter($_SESSION[$vt->a("isim")."userid"], 1);?>  </td></font></font></td>
</tr>
<tr>
<td><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">En son giriş:</font></font></td>
<td><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><?= $WMinf->tarih_format('j F Y , l,  H:i:s', $vt->uye("last_play"));  ?> </font></font></td>
</tr>
<tr>
<td><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Telefon:</font></font></td>
<td><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><?=$WMinf->kisalt($vt->uye("phone1"), 7, "****");?></font></font></td>
</tr>
</tbody></table>
</div>
<div class="col">
<h2 class="title"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Ayarlar</font></font></h2>
<ul class="list-unstyled overview-linklist" style="list-style:none;line-height:2.5;">
<li><a class="blue-a" ><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Bildirimler (<?=$bildirimler->rowCount();?>)</font></font></a></li>
<li> <?php if($vt->a("kullanici_degis") != 3){?><a class="blue-a" href="kullanici/kullanici-adi-degistir"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Kullanıcı Adı Değiştir</font></font></a></li><?php } ?>
<li><a class="blue-a" href="kullanici/karakter-silme-sifresi-degistir"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;"><?=($vt->a("karakter_silme_sifre") == 1 || $vt->a("karakter_silme_sifre") == 3) ? "K. Silme Ş. Değiştir" : "K. Silme Ş. İste";?></font></font></a></li>
<li><a class="blue-a" href="kullanici/karakterlerim"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Karakterlerim (<?=$tema->kac_karakter($_SESSION[$vt->a("isim")."userid"]);?>)</font></font></a></li>
<li><a class="blue-a iframe payment-page" href="kullanici/bugdan-kurtar"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Bugdan Kurtar</font></font></a></li>
<li>&nbsp;</li>
<li><a class="blue-a" href="cikis-yap"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Çıkış Yap</font></font></a></li>
</ul>
</div>
</div>
</div>
</div>