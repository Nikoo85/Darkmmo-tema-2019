<?php if(!defined("WM_HTML_KONTROL")){ die("Buraya giriş izniniz yoktur."); exit;} ?>

<div class="news-block">
<div class="content-title">

</div>
<script>
function refreshCaptcha() {
	$("img#captcha_code").attr('src','<?=WMcaptcha;?>');
}
</script>
<form action="javascript:;" method="post" id="kaydol">
<input type="hidden" name="kayit_token" value="<?=$ayar->sessionid;?>">	
<section style="padding: 20px;">
<span class="title">Adınız Ve Soyadınız</span>
<div class="row" style="margin: 10px">
<div class="col"><input id="account" name="real_name" class="field" maxlength="16" size="25" title="" data-toggle="popover" placeholder="Adınız Soyadınız" type="text" data-original-title="20 Karakterden Daha Uzun Olmasın" onkeyup="turkce_kontrol(this)"></div>
<div class="col">Bu, Destek Biletlerinde ve Ana Sayfa'da görünen ad olarak kullandığımız addır.</div>
</div>
<span class="title">Kullanıcı Adı</span>
<div class="row" style="margin: 10px">
<div class="col"><input id="uname" name="username" class="field" maxlength="16" size="25" placeholder="Kullanıcı Adı" type="text" onkeyup="turkce_kontrol(this)">
</div>
<div class="col">
Oyuna giriş yapmak için kullanmak istediğiniz adı girin.</div>
</div>
<br>
<span class="title">Şifre</span>
<div class="row" style="margin: 10px">
<div class="col">
<p>
<input id="password" class="field" name="pass" required="" data-toggle="popover" title="" data-content="Passwort eingeben ..." placeholder="Şifre" maxlength="16" size="25" type="password" data-original-title="Şifre">
</p>
<p>
<input id="password_confirmation" class="field" name="pass_retry" placeholder="Şifre Tekrar" maxlength="16" size="25" type="password">
</p>
</div>

<div class="col"><p>Güvenliğiniz bizim için önemlidir. Lütfen yalnızca Darkmmomt2 için kullanacağınız yeni bir güvenli şifre seçin.</p>

<p>Asla e-posta adresiniz için kullandığınız şifreyi asla kullanmayın.</p></div>

</div>
<span class="title">E-Posta Adresiniz</span>
<div class="row" style="margin: 10px">
<div class="col">
<p><input id="email" class="field" name="eposta" size="25" placeholder="E-Posta Adresiniz" type="text"></p>
</div>
<div class="col">
<p>Daha iyi ve kolay destek için bize e-posta adresinizi vermelisiniz.</p>
<br>
</div>
</div>
<span class="title">Karakter Silme Kodu & Telefon No.</span>
<div class="row" style="margin: 10px">
<div class="col">
<p>
<input id="password" class="field" name="social_id" required="" data-toggle="popover" title="" onkeyup="sayi_kontrol(this)" placeholder="Karakter Silme Kodu" maxlength="7" size="25" type="password" data-original-title="Passwort stärke">
</p>
<p>
<input id="password_confirmation" class="field" name="phone_number" placeholder="Telefon Numaranız" onkeyup="sayi_kontrol(this)" maxlength="11" size="25" type="text">
</p>
</div>
<div class="col">
<p>Karakterinizi Silmenize Yarayan Bir Güvenlik Kodudur</p>
<p>Size Kısa Mesaj Göndererek Bilgilendirme Yapacağız.</p>
</div>
</div>

<span class="title">Güvelik Doğrulaması</span>

<div class="row" style="margin: 10px">
<div class="col">
<div><img src="<?=WMcaptcha;?>" id="captcha_code" /> <a href="javascript:;" onClick="refreshCaptcha();"><img src="<?=$ayar->WMimg;?>refresh.png" /></a></div>
<p>
<input id="password" class="field" name="captcha_code" required="" data-toggle="popover" title="" data-content="Passwort eingeben ..." placeholder="Güvenlik Kodu" maxlength="4" size="25" type="text" data-original-title="Passwort stärke">
</p>
</div>
<div class="col">
</div>
</div>
<input class="validate[required]" type="checkbox" name="sozlesme" id="checkbox" value="1">
Okudum ve onaylıyorum <a href="" id="rules_dialog"><b>oyun kuralları.</b></a>	
<ul class="list-inline pull-right">
<li>
<button type="submit" class="btn btn-primary bg-color-df">Kayıt Ol</button>
</li>
</ul>
</section>
</form>
</div>