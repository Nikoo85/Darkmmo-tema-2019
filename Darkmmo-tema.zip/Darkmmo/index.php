<?php 
require_once 'sayfalar/class.php';

$srv = new server;

?>
<html>
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<?php $wmcp->head(); ?>
<?php $tema->stiller(); ?>
<meta name="description" content="Nikoo85">
<meta name="publisher" content="Nikoo85">
<meta name="keywords" content="Nikoo85">
<meta name="MobileOptimized" content="320">
<meta name="HandheldFriendly" content="True">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="viewport" content="initial-scale=1,maximum-scale=1,minimum-scale=1,user-scalable=no,width=device-width">
<meta name="theme-color" content="#ffffff">
<link rel="stylesheet" href="<?=WM_tema;?>build/css/app-3a17e83221.css">
<link rel="stylesheet" href="<?=WM_tema;?>build/css/genel.css">
<link rel="stylesheet" href="<?=WM_tema;?>build/js/jquery/jquery.min.js">
<link href='https://fonts.googleapis.com/css?family=Open+Sans:400,300,700' rel='stylesheet' type='text/css'>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" type="text/css">
</head>
<body class="home">
<div id="sonuc"></div>
<div class="wrapper">
<header class="header">
<div class="menu-top">
<ul class="menu-top-left">
<li><a href="anasayfa">Anasayfa</a></li>
<li><a href="kaydol">Kayıt Ol</a></li>
<li><a href="oyunu-indir">İndir</a></li>
<li><a href="oyuncu-siralamasi">Sıralama</a></li>
</ul>
<ul class="menu-top-right">
<li><a href="https://www.darkmmo.com/">Forum</a>
<ul>
<li><a href="https://www.darkmmo.com/">Forum</a></li>
<li><a href="https://www.darkmmo.com/">Forum</a></li>
<li><a href="https://www.darkmmo.com/">Forum</a></li>
<li><a href="https://www.darkmmo.com/">Forum</a></li>
</ul>
</li>
<li><a href="https://www.darkmmo.com/">Forum</a></li>
<li><a href="https://www.darkmmo.com/">Forum</a>
</li>
<li><a href="https://www.darkmmo.com/">Forum</a>
<ul>
<li><a href="https://www.darkmmo.com/">Forum</a></li>
<li><a href="https://www.darkmmo.com/">Forum</a></li>
<li><a href="https://www.darkmmo.com/">Forum</a></li>
</ul>
</li>
</ul>
<div class="circle-online">
<div class="server-l">
Online <br> Oyuncu:
</div>
<div class="server-on" id="online_oyuncu">
124
</div>
<div class="circlestat" data-dimension="110" data-width="6" data-fontsize="12" data-percent="11" data-fgcolor="rgba(5, 214, 127, 1000)" data-bgcolor="#08251a"></div>
</div>
<div class="logo-effect">
<div class="logo-effect-1">
</div>
<div class="logo-effect-2">
</div>
<div class="logo-effect-3">
</div>
<div class="logo-effect-4">
</div>
</div>
<div class="hand">
<div class="hand-effect-3">
</div>
<div class="hand-effect-2">
</div>
<div class="hand-effect-1">
</div>
</div>
</div>
<div class="logo">
<a href="/"></a>
</div>
</header>
<div class="container container-top">
<?php if(!isset($_SESSION[$vt->a("isim")."token"])){ ?>
<div class="login-panel">
<div class="login-title title">
Kullanıcı Girişi</div>
<form method="post" action="javascript:;" id="giris">
<input type="hidden" name="giris_csrf_token" value="<?=$ayar->sessionid;?>" />
<input type="hidden" value="<?=$ayar->sessionid;?>" name="giris_token" />
<p><input type="text" name="username" placeholder="Kullanıcı Adı" class="login"></p>
<p><input type="password" name="pass" placeholder="Şifre" class="pass"></p>
<button>Giriş Yap</button>
</form>
<div class="acc-p">
<a href="kaydol">Kayıt Ol</a> <a href="sifremi-unuttum">Şifremi Unuttum?</a>
</div>
</div>
<?php }else{ ?>
<?php } ?>
<?php if(!isset($_SESSION[$vt->a("isim")."token"])){ ?>
<div class="slider">
<div class="next"> </div>
<div class="prev"> </div>
<div class="slides">
<div class="slide">
<img src="<?=WM_tema;?>build/img/image1.jpg" alt="">
<span>Darkmmo Türkiye'nin En İyi MMO Forum Platformu</span>
</div>
<div class="slide">
<img src="<?=WM_tema;?>build/img/image1.jpg" alt="">
<span>Darkmmo Türkiye'nin En İyi MMO Forum Platformu</span>
</div>
<div class="slide">
<img src="<?=WM_tema;?>build/img/image1.jpg" alt="">
<span>Darkmmo Türkiye'nin En İyi MMO Forum Platformu</span>
</div>
</div>
<div class="navigation">
</div>
</div>
<?php }else{ ?>
<style>
.slider {
    overflow: hidden;
    position: relative;
    width: 847px;
    background: url(https://i.hizliresim.com/Gmjg2Z.jpg);
    margin: 0px auto;
}
</style>
<div class="slider">
<div class="next"> </div>
<div class="prev"> </div>
<div class="slides" style="width: 1620px; transform: translate3d(-1080px, 0px, 0px);">
</div>
<div class="navigation">
<div class="dot"></div><div class="dot"></div><div class="dot active"></div></div>
</div>
<?php } ?>
<div class="sidebar-top">
<a href="oyunu-indir" class="download-button"> <span>Kurulum</span> Dosya Boyutu 10 Tb</a>
<a id="itemshop" href="market" class="item-shop-button"> <span>Nesne Market</span> Hadi Para Harcayak...</a>
</div>
</div>
<div class="container">
<main class="page content">
<div class="news-block">
<div class="content-title">
<span class="title"><?=$wmcp->ust();?></span>
</div>
<div class="tab-n news active" id="news-1">
<?=$wmcp->orta();?> 
</div>
<div class="tab-n news" id="news-2">
2
</div>
</div>
</main>
<aside class="sidebar">
<?php if(!isset($_SESSION[$vt->a("isim")."token"])){ ?>
<?php }else{ ?>
<div class="usercp-block">
<div class="sidebar-title">
<span><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">UserCP</font></font></span>
</div>
<div class="block-p usercp">
<ul>
<li><a href="kullanici"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Hesabım</font></font></a></li>
<li><a><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Ep: <?=$vt->uye("coins");?></font></font></a></li>
<li><a href="<?=$vt->url(11);?>"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Market</font></font></a></li>
<li><a href="cikis-yap"><font style="vertical-align: inherit;"><font style="vertical-align: inherit;">Çıkış Yap</font></font></a></li>
</ul>
</div>
</div>
<?php } ?>
<div class="ranking-block">
<div class="sidebar-title">
<span>Drop & İstatik</span>
</div>
<div class="block-p ranking">

<ul>
<?php if($tema->istatistikler(1) == 1){ ?>
<li> <span title="Bugün Girenler" class="nickname">Toplam Lonca <span class="level-text" id="toplam_lonca">Error</span></span></li>
<?php } ?>
<?php if($tema->istatistikler(2) == 1){ ?>
<li> <span title="Bugün Girenler" class="nickname">Rekor Online <span class="level-text" id="rekor_online">Error</span></span></li>
<?php } ?>
<?php if($tema->istatistikler(3) == 1){ ?>
<li> <span title="Bugün Girenler" class="nickname">Toplam Kayıt <span class="level-text" id="toplam_kayit">Error</span></span></li>
<?php } ?>
<?php if($tema->istatistikler(4) == 1){ ?>
<li> <span title="Bugün Girenler" class="nickname">Toplam Oyuncu <span class="level-text" id="toplam_karakter">Error</span></span></li>
<?php } ?>
<?php if($tema->droplar(0) == 1 || $tema->droplar(1) == 1 || $tema->droplar(2) == 1 ){ ?>
<?php if($tema->droplar(0) == 1){ ?>
<li> <span title="Exp Kazanma" class="nickname">Exp Kazanma <span class="level-text">%<?=$tema->drop(0);?></span></span></li>
<?php } ?>
<?php if($tema->droplar(1) == 1){ ?>
<li> <span title="Yang Düşürme" class="nickname">Yang Düşürme <span class="level-text">%<?=$tema->drop(1);?></span></span></li>
<?php } ?>
<?php if($tema->droplar(2) == 1){ ?>
<li> <span title="Yang Düşürme" class="nickname">Eşya Düşürme <span class="level-text">%<?=$tema->drop(2);?></span></span></li>
<?php } ?>
<?php } ?>
</ul>
</div>
</div>
<div class="ranking-block">
<div class="sidebar-title">
<div class="top-title">
TOP <b>5</b>
</div>
<span>Oyuncu Sırlaması</span>
</div>
<div class="block-p ranking">
<ul>
<?=$srv->karakter(5);?>
</ul>
</div>
</div>
<div class="guilds-block">
<div class="sidebar-title">
<div class="top-title">
TOP <b>5</b>
</div>
<span>Lonca Sıralaması</span>
</div>
<div class="block-p ranking">
<ul>
<?=$srv->lonca(5);?>
</ul>
</div>
</div>
<div class="fan-page">
<a href="https://www.darkmmo.com/" title="Darkmmo" class="fanpage"></a>

</div>

</aside>
</div>
<footer class="footer">
<div class="footer-top">
<div class="footer-logo">
<a href="/"></a>
</div>
</div>
<div class="footer-menu">
<ul>
<li><a href="anasayfa">Anasayfa</a></li><li><a href="kaydol">Kayıt Ol</a></li><li><a href="oyunu-indir">İndir</a></li>
<li><a href="destek">Destek</a></li>
<li><a href="http://www.darkmmo.com/">Darkmmo</a></li>
<li><a href="http://www.darkmmo.com/">Facebook</a></li>
<li><a href="http://www.darkmmo.com/">Forum</a></li>
</ul>
</div>
<div class="copyright">
&copy; 2019 by Darkmmo Nikoo85. Tüm Haklar Saklıdır.
</div>
</footer>
</div>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.4/jquery.min.js"></script>
<script src="<?=WM_tema;?>build/js/app-eee0adda38.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.20.1/moment.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datetimepicker/4.17.47/js/bootstrap-datetimepicker.min.js"></script>
<script>
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
    </script>
<?php 
$tema->jquery($konum); 
$tema->footer();
?>	
</body>
</html>
